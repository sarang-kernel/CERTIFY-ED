"""Validation experiments and figure generation"""

from .experiments import (
    run_bethe_ansatz_validation,
    run_quspin_validation_mock,
    run_cross_platform_test,
    generate_figure_1_architecture,
    generate_figure_2_consensus,
    generate_figure_3_scalability,
    generate_figure_4_reproducibility,
    generate_figure_5_error_bounds,
    generate_figure_6_performance,
    generate_figure_7_heisenberg_validation,
    generate_figure_8_quspin_validation,
)

__all__ = [
    "run_bethe_ansatz_validation",
    "run_quspin_validation_mock",
    "run_cross_platform_test",
    "generate_figure_1_architecture",
    "generate_figure_2_consensus",
    "generate_figure_3_scalability",
    "generate_figure_4_reproducibility",
    "generate_figure_5_error_bounds",
    "generate_figure_6_performance",
    "generate_figure_7_heisenberg_validation",
    "generate_figure_8_quspin_validation",
]
