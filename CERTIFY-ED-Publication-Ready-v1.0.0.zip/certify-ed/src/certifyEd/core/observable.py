"""
PHASE 5: Observable Validation & Error Propagation
====================================================

Computes expectation values with certified error bounds (Theorem 2).
Implements paper §3.5.

Author: Sarang Vehale
License: MIT
"""

import numpy as np
from typing import Dict, Any, Tuple
from dataclasses import dataclass


@dataclass
class ObservableResult:
    """Result of observable computation with certified error bound"""
    value: float
    error: float
    certified: bool

    def __repr__(self):
        return f"{self.value:.12f} ± {self.error:.2e}"


class ObservableCalculator:
    """Phase 5: Observable Validation with Error Bounds (Paper §3.5)"""

    def __init__(self, results):
        """Initialize observable calculator."""
        self.results = results

    def expectation_value(self, observable: np.ndarray, 
                         state_index: int = 0) -> ObservableResult:
        """
        Compute ⟨ψ|O|ψ⟩ with certified error bounds (Theorem 2, Paper §2.4).

        Args:
            observable: Operator matrix O
            state_index: Which eigenstate (default: ground state)

        Returns:
            ObservableResult with value and certified error bound
        """
        psi = self.results.eigenvectors[:, state_index]
        exp_val = np.real(np.conj(psi) @ observable @ psi)

        M = np.linalg.norm(observable, ord=2)
        epsilon = self.results.epsilon

        if state_index < len(self.results.eigenvalues) - 1:
            gap = (self.results.eigenvalues[state_index + 1] - 
                  self.results.eigenvalues[state_index])
        else:
            gap = 1.0

        certified = True
        if gap > 2 * epsilon:
            error = 2 * M * (2 * epsilon / gap) + epsilon * M
        else:
            error = float('inf')
            certified = False

        return ObservableResult(
            value=float(exp_val),
            error=float(error),
            certified=certified
        )

    def summary(self) -> Dict[str, Any]:
        """Get summary of certified observables (Phase 5)."""
        E0 = self.results.ground_state_energy()
        E1 = self.results.eigenvalues[1] if len(self.results.eigenvalues) > 1 else E0
        gap = E1 - E0
        residuals = self.results.compute_residuals()

        return {
            "ground_state_energy": E0,
            "energy_error_bound": residuals[0],
            "first_excited_state_energy": E1,
            "spectral_gap": float(gap),
            "epsilon": self.results.epsilon,
            "agreement_validated": self.results.agreement_validated,
        }
