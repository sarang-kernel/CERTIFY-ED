"""
PHASE 1: Symbolic Construction & Hermiticity Verification
===========================================================

Constructs Hamiltonians symbolically and verifies H = H† exactly.
Implements paper §3.1.

Author: Sarang Vehale
License: MIT
"""

import numpy as np
import json
import hashlib
from typing import Dict, Any, List
from datetime import datetime


class CertifiedHamiltonian:
    """Phase 1: Symbolic Hamiltonian Construction with Hermiticity Verification"""

    def __init__(self, dimension: int, model_name: str = "Custom"):
        """
        Initialize a certified Hamiltonian.

        Args:
            dimension: Hilbert space dimension
            model_name: Name of the model (e.g., "TFIM", "Heisenberg")
        """
        self.dimension = dimension
        self.model_name = model_name
        self.H = np.zeros((dimension, dimension), dtype=complex)
        self.is_hermitian = False
        self.parameters = {}
        self.conserved_quantities = []

    @staticmethod
    def tensor_product_safe(A: np.ndarray, B: np.ndarray) -> np.ndarray:
        """
        Safely compute tensor product with consistent complex dtype.

        CRITICAL FIX: Ensures A and B are complex before Kronecker product
        to avoid dtype mismatch errors (float64 + complex128).

        Args:
            A: First matrix
            B: Second matrix

        Returns:
            A ⊗ B with consistent dtype=complex
        """
        A_complex = np.array(A, dtype=complex)
        B_complex = np.array(B, dtype=complex)
        return np.kron(A_complex, B_complex)

    @classmethod
    def TFIM(cls, L: int, J: float, h: float) -> 'CertifiedHamiltonian':
        """
        Transverse-Field Ising Model (Paper §3.1)

        H = -J Σ_i σᶻᵢσᶻᵢ₊₁ - h Σ_i σˣᵢ

        Args:
            L: Number of spins (system size)
            J: Coupling strength
            h: Transverse field strength

        Returns:
            CertifiedHamiltonian with TFIM
        """
        dimension = 2**L
        hamiltonian = cls(dimension, "TFIM")
        hamiltonian.parameters = {"L": L, "J": J, "h": h}

        sigma_x = np.array([[0, 1], [1, 0]], dtype=complex)
        sigma_z = np.array([[1, 0], [0, -1]], dtype=complex)
        identity = np.array([[1, 0], [0, 1]], dtype=complex)

        H = np.zeros((dimension, dimension), dtype=complex)

        # ZZ interactions
        for i in range(L):
            op = cls._build_two_body_operator(L, i, (i+1) % L, sigma_z, sigma_z)
            H += -J * op

        # Transverse field
        for i in range(L):
            op = cls._build_single_body_operator(L, i, sigma_x)
            H += -h * op

        hamiltonian.H = H
        return hamiltonian

    @classmethod
    def Heisenberg(cls, L: int, J: float = 1.0, Jz: float = None,
                  periodic: bool = True) -> 'CertifiedHamiltonian':
        """
        Heisenberg Model (Paper §3.1)

        H = J Σ_i (σˣᵢσˣᵢ₊₁ + σʸᵢσʸᵢ₊₁ + Jz σᶻᵢσᶻᵢ₊₁)

        Args:
            L: Number of spins
            J: XX and YY coupling
            Jz: ZZ coupling (default: same as J for isotropic)
            periodic: Periodic boundary conditions

        Returns:
            CertifiedHamiltonian with Heisenberg model
        """
        if Jz is None:
            Jz = J

        dimension = 2**L
        hamiltonian = cls(dimension, "Heisenberg_XXZ")
        hamiltonian.parameters = {"L": L, "J": J, "Jz": Jz}

        sigma_x = np.array([[0, 1], [1, 0]], dtype=complex)
        sigma_y = np.array([[0, -1j], [1j, 0]], dtype=complex)
        sigma_z = np.array([[1, 0], [0, -1]], dtype=complex)

        H = np.zeros((dimension, dimension), dtype=complex)

        num_bonds = L if periodic else L-1
        for i in range(num_bonds):
            j = (i+1) % L if periodic else i+1

            op_xx = cls._build_two_body_operator(L, i, j, sigma_x, sigma_x)
            H += J * op_xx

            op_yy = cls._build_two_body_operator(L, i, j, sigma_y, sigma_y)
            H += J * op_yy

            op_zz = cls._build_two_body_operator(L, i, j, sigma_z, sigma_z)
            H += Jz * op_zz

        hamiltonian.H = H
        return hamiltonian

    @staticmethod
    def _build_single_body_operator(L: int, site: int, op: np.ndarray) -> np.ndarray:
        """Build tensor product for single-site operator."""
        identity = np.array([[1, 0], [0, 1]], dtype=complex)
        result = np.array([[1]], dtype=complex)

        for i in range(L):
            if i == site:
                result = CertifiedHamiltonian.tensor_product_safe(result, op)
            else:
                result = CertifiedHamiltonian.tensor_product_safe(result, identity)
        return result

    @staticmethod
    def _build_two_body_operator(L: int, site1: int, site2: int, 
                                op1: np.ndarray, op2: np.ndarray) -> np.ndarray:
        """Build tensor product for two-site operator."""
        identity = np.array([[1, 0], [0, 1]], dtype=complex)
        result = np.array([[1]], dtype=complex)

        for i in range(L):
            if i == site1:
                result = CertifiedHamiltonian.tensor_product_safe(result, op1)
            elif i == site2:
                result = CertifiedHamiltonian.tensor_product_safe(result, op2)
            else:
                result = CertifiedHamiltonian.tensor_product_safe(result, identity)
        return result

    def verify_hermiticity(self) -> bool:
        """
        Phase 1 (Paper §3.1): Verify H = H† exactly.

        Raises:
            ValueError: If not Hermitian (||H - H†|| > 1e-14)

        Returns:
            True if Hermitian
        """
        H_dag = np.conj(self.H.T)
        diff = np.linalg.norm(self.H - H_dag, 'fro')

        if diff > 1e-14:
            raise ValueError(f"Non-Hermitian Hamiltonian! ||H - H†|| = {diff:.2e}")

        self.is_hermitian = True
        return True

    def export_specification(self) -> Dict[str, Any]:
        """Export Hamiltonian specification with SHA-256 hash."""
        spec = {
            "model": self.model_name,
            "dimension": self.dimension,
            "parameters": self.parameters,
            "hermitian": self.is_hermitian,
            "timestamp": datetime.now().isoformat()
        }
        spec_str = json.dumps(spec, sort_keys=True)
        spec["specification_hash"] = hashlib.sha256(spec_str.encode()).hexdigest()
        return spec
