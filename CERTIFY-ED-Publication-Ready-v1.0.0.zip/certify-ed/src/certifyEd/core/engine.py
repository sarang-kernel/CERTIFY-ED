"""
PHASE 4: Certificate Generation & Cryptographic Hashing
=========================================================

Generates exportable proof certificates with SHA-256 hashing.
Implements paper §3.4.

Author: Sarang Vehale
License: MIT
"""

import json
import hashlib
import numpy as np
from typing import Dict, Any
from datetime import datetime


class Certificate:
    """Phase 4: Proof Certificate Generation (Paper §3.4)"""

    def __init__(self, results):
        """Create certificate from diagonalization results."""
        self.results = results
        self.residuals = results.compute_residuals()
        self.timestamp = datetime.now().isoformat()

    def to_dict(self) -> Dict[str, Any]:
        """Convert certificate to exportable dictionary."""
        cert = {
            "metadata": {
                "model": self.results.hamiltonian.model_name,
                "dimension": self.results.hamiltonian.dimension,
                "parameters": self.results.hamiltonian.parameters,
                "timestamp": self.timestamp,
                "oracle_names": [r.name for r in self.results.oracle_results],
            },
            "certification": {
                "epsilon": self.results.epsilon,
                "agreement_validated": self.results.agreement_validated,
                "eigenvalues": self.results.eigenvalues.tolist(),
                "residuals": self.residuals.tolist(),
            },
        }

        cert_str = json.dumps(cert, sort_keys=True, indent=2)
        cert["certificate_hash"] = hashlib.sha256(cert_str.encode()).hexdigest()

        return cert

    def export_json(self, filename: str):
        """Export certificate to JSON file."""
        cert_dict = self.to_dict()
        with open(filename, 'w') as f:
            json.dump(cert_dict, f, indent=2)

    def verify(self, hamiltonian_to_verify) -> bool:
        """Verify certificate integrity (Theorem 3, Paper §2.5)."""
        H = hamiltonian_to_verify.H

        for n in range(len(self.results.eigenvalues)):
            psi = self.results.eigenvectors[:, n]
            E = self.results.eigenvalues[n]
            residual = np.linalg.norm(H @ psi - E * psi)

            if residual > 2 * self.results.epsilon:
                return False
        return True

    def get_summary(self) -> str:
        """Get human-readable certificate summary."""
        cert = self.to_dict()

        summary = f"""
╔═══════════════════════════════════════════════════════════╗
║           CERTIFICATION SUMMARY                           ║
╚═══════════════════════════════════════════════════════════╝

Model: {cert['metadata']['model']}
Parameters: {cert['metadata']['parameters']}
Dimension: {cert['metadata']['dimension']}

Ground State Energy: {cert['certification']['eigenvalues'][0]:.15f}
Spectral Gap: {cert['certification']['eigenvalues'][1] - cert['certification']['eigenvalues'][0]:.15f}

Tolerance (ε): {cert['certification']['epsilon']:.2e}
Agreement Validated: {cert['certification']['agreement_validated']}

Certificate Hash: {cert['certificate_hash'][:16]}...

╔═══════════════════════════════════════════════════════════╗
║  Ready for archival and cross-platform verification      ║
╚═══════════════════════════════════════════════════════════╝
"""
        return summary
